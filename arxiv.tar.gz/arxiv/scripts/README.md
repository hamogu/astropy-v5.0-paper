This directory contains other scripts that are used in the paper build workflow.
Any code that produces a figure should instead be in ../figures